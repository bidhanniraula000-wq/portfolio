document.addEventListener("DOMContentLoaded", () => {

  /* ---------------- YEAR ---------------- */
  document.getElementById("year").textContent = new Date().getFullYear();

  /* ---------------- LOADER ---------------- */
  const loader = document.getElementById("loader");
  window.addEventListener("load", () => {
    setTimeout(() => loader.classList.add("is-hidden"), 500);
  });

  /* ---------------- CURSOR GLOW ---------------- */
  const cursorGlow = document.getElementById("cursorGlow");
  const isCoarsePointer = window.matchMedia("(hover: none), (pointer: coarse)").matches;
  if (!isCoarsePointer) {
    window.addEventListener("mousemove", (e) => {
      cursorGlow.style.left = e.clientX + "px";
      cursorGlow.style.top = e.clientY + "px";
    });
    document.querySelectorAll("a, button, .skill-card, .badge").forEach((el) => {
      el.addEventListener("mouseenter", () => cursorGlow.classList.add("is-active"));
      el.addEventListener("mouseleave", () => cursorGlow.classList.remove("is-active"));
    });
  }

  /* ---------------- THEME TOGGLE ---------------- */
  const root = document.documentElement;
  const themeToggle = document.getElementById("themeToggle");
  const savedTheme = localStorage.getItem("bn-theme");
  if (savedTheme) root.setAttribute("data-theme", savedTheme);

  themeToggle.addEventListener("click", () => {
    const current = root.getAttribute("data-theme") === "light" ? "light" : "dark";
    const next = current === "light" ? "dark" : "light";
    if (next === "dark") {
      root.removeAttribute("data-theme");
    } else {
      root.setAttribute("data-theme", "light");
    }
    localStorage.setItem("bn-theme", next);
  });

  /* ---------------- NAV: burger + scroll spy ---------------- */
  const burger = document.getElementById("navBurger");
  const navLinks = document.getElementById("navLinks");
  burger.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("is-open");
    burger.classList.toggle("is-open", isOpen);
    burger.setAttribute("aria-expanded", String(isOpen));
  });
  navLinks.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => {
      navLinks.classList.remove("is-open");
      burger.classList.remove("is-open");
      burger.setAttribute("aria-expanded", "false");
    })
  );

  const sections = document.querySelectorAll("section[id]");
  const navAnchors = document.querySelectorAll(".nav__link");
  const spyObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          navAnchors.forEach((a) => a.classList.remove("active-link"));
          const active = document.querySelector(`.nav__link[href="#${entry.target.id}"]`);
          if (active) active.classList.add("active-link");
        }
      });
    },
    { rootMargin: "-45% 0px -45% 0px" }
  );
  sections.forEach((s) => spyObserver.observe(s));

  /* ---------------- TYPING ANIMATION ---------------- */
  const typingEl = document.getElementById("typingText");
  const roles = ["Python Developer", "Data Analyst", "Aspiring Data Scientist"];
  let roleIndex = 0, charIndex = 0, deleting = false;

  function typeLoop() {
    const current = roles[roleIndex];
    if (!deleting) {
      charIndex++;
      typingEl.textContent = current.slice(0, charIndex);
      if (charIndex === current.length) {
        deleting = true;
        setTimeout(typeLoop, 1400);
        return;
      }
    } else {
      charIndex--;
      typingEl.textContent = current.slice(0, charIndex);
      if (charIndex === 0) {
        deleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
      }
    }
    setTimeout(typeLoop, deleting ? 45 : 85);
  }
  typeLoop();

  /* ---------------- SCROLL REVEAL ---------------- */
  const revealEls = document.querySelectorAll(".reveal");
  const revealObserver = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  revealEls.forEach((el) => revealObserver.observe(el));

  /* ---------------- SKILL BARS (replays every time you scroll past) ---------------- */
  const skillEls = document.querySelectorAll(".skill");

  function countUp(el, target) {
    clearInterval(el._countTimer);
    let current = 1;
    el.textContent = current + "%";
    const duration = 1800; // total time in ms to reach the target — matches the bar fill speed
    const stepTime = duration / target;
    el._countTimer = setInterval(() => {
      current += 1;
      if (current >= target) {
        current = target;
        clearInterval(el._countTimer);
      }
      el.textContent = current + "%";
    }, stepTime);
  }

  const skillObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        const bar = entry.target.querySelector(".skill__bar");
        const valueEl = entry.target.querySelector(".skill__value");
        const percent = parseInt(entry.target.getAttribute("data-percent"), 10);
        if (entry.isIntersecting) {
          requestAnimationFrame(() => { bar.style.width = percent + "%"; });
          countUp(valueEl, percent);
        } else {
          bar.style.width = "0%";
          clearInterval(valueEl._countTimer);
          valueEl.textContent = "0%";
        }
      });
    },
    { threshold: 0.4 }
  );
  skillEls.forEach((el) => skillObserver.observe(el));

  /* ---------------- RIPPLE BUTTONS ---------------- */
  document.querySelectorAll(".ripple").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const rect = btn.getBoundingClientRect();
      btn.style.setProperty("--rx", `${e.clientX - rect.left}px`);
      btn.style.setProperty("--ry", `${e.clientY - rect.top}px`);
      btn.classList.remove("is-rippling");
      void btn.offsetWidth; // restart animation
      btn.classList.add("is-rippling");
    });
  });

  /* ---------------- PROJECT MODAL ---------------- */
  const modal = document.getElementById("projectModal");
  const openModalBtn = document.getElementById("openModalBtn");
  const closeModalBtn = document.getElementById("closeModalBtn");

  function openModal() {
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
  function closeModal() {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }
  openModalBtn.addEventListener("click", openModal);
  closeModalBtn.addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.classList.contains("is-open")) closeModal();
  });

  /* ---------------- BACK TO TOP ---------------- */
  document.getElementById("backToTop").addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ---------------- CONTACT FORM ---------------- */
  const form = document.getElementById("contactForm");
  const statusEl = document.getElementById("formStatus");
  const sendBtn = document.getElementById("sendBtn");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const subject = form.subject.value.trim();
    const message = form.message.value.trim();

    if (!name || !email || !subject || !message) {
      statusEl.textContent = "Please fill in every field.";
      statusEl.className = "form__status err";
      return;
    }

    // ---------------------------------------------------------------
    // EmailJS integration (recommended): once you add the EmailJS SDK
    // script tag and create a service + template at emailjs.com, replace
    // the block below with:
    //
    //   emailjs.init("YOUR_PUBLIC_KEY");
    //   emailjs.sendForm("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", form)
    //     .then(() => {
    //       statusEl.textContent = "Message sent — thank you!";
    //       statusEl.className = "form__status ok";
    //       form.reset();
    //     })
    //     .catch(() => {
    //       statusEl.textContent = "Something went wrong. Please try again.";
    //       statusEl.className = "form__status err";
    //     });
    //
    // Until then, this falls back to opening the visitor's email client
    // with the message pre-filled, so the form works right out of the box.
    // ---------------------------------------------------------------
    if (window.emailjs) {
      sendBtn.disabled = true;
      window.emailjs
        .sendForm("YOUR_SERVICE_ID", "YOUR_TEMPLATE_ID", form)
        .then(() => {
          statusEl.textContent = "Message sent — thank you!";
          statusEl.className = "form__status ok";
          form.reset();
        })
        .catch(() => {
          statusEl.textContent = "Something went wrong. Please try again.";
          statusEl.className = "form__status err";
        })
        .finally(() => { sendBtn.disabled = false; });
    } else {
      const body = encodeURIComponent(`From: ${name} (${email})\n\n${message}`);
      const mailto = `mailto:bidhanniraula000@gmail.com?subject=${encodeURIComponent(subject)}&body=${body}`;
      window.location.href = mailto;
      statusEl.textContent = "Opening your email client to send this message…";
      statusEl.className = "form__status ok";
    }
  });

});