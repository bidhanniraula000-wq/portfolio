import pandas as pd
import streamlit as st

# # Set wide layout so boxes fit nicely
# st.set_page_config(layout="wide")

st.markdown(
    """
    <style>
    .stApp {
        background-color: lightgray;
    }

    section[data-testid="stSidebar"] {
        background-color: #001F35;
        border-radius: 0px 20px 20px 0px;
    }

    div[data-testid="stMainBlockContainer"] {
        padding-left: 5px !important;
        padding-right: 5px !important;
        padding-top: 5rem !important;
    }

    .sidebar-divider {
        width: 85%;
        height: 1px;
        background-color: rgba(255,255,255,0.2);
        margin: 15px auto;
    }

    .sidebar-title {
        font-family: Arial;
        font-size: 32px;
        font-weight: bold;
        color: white;
        text-align: center;
        letter-spacing: 2px;
        margin-top: 10px;
    }

    .sidebar-subtitle {
        font-family: Arial;
        font-size: 11px;
        color: white;
        text-align: center;
        margin-top: 3px;
        margin-bottom: 0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label {
        display: flex !important;
        flex-direction: row-reverse;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        padding: 10px;
        cursor: pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p {
        color: white !important;
        font-size: 16px;
        font-family: Arial;
    }

    .home-icon {
        position: fixed;
        bottom: 25px;
        left: 30px;
        width: 42px;
        height: 42px;
        border-radius: 5px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 20px;
        box-shadow: 0px 2px 6px rgba(0,0,0,0.4);
        background-color: #001F35;
    }

    .home-icon:hover {
        transform: scale(1.08);
        box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
    }


    .st-key-attendance-dashboard,
    .st-key-attendance-detail-box,
    .st-key-attendance-status {
        background-color: white !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        width: 100% !important; 
        min-width: 900px !important;  
    }

    .attendance {
        font-family: Arial;
        color: white;
        font-weight: bold;
        font-size: 18px !important;
    }

    .st-key-attendance-dashboard-box,
    .st-key-session {
        background-color: #E87B12 !important;
        border: none !important;
        padding: 15px 20px;
        border-radius: 8px;
        margin-bottom: 15px;
        width: 85% !important;          
    }

    .session-details {
        font-family: Arial;
        color: white;
        font-weight: bold;
        font-size: 16px !important;
    }

    .semester {
        font-family: Arial;
        color: black;
        font-weight: bold;
        font-size: 24px !important;
    }

    div[data-testid="stSelectbox"] label {
        font-family: Arial;
        font-weight: bold;
        font-size: 16px !important;
        color: black;  
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# --- SIDEBAR AREA ---
with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">🎓SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-subtitle">'
        "Students Performance Analytic and attendance<br>Monitoring System"
        "</div>",
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting",
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )


# --- MAIN PAGE AREA (NOT INDENTED UNDER SIDEBAR) ---
with st.container(key="attendance-dashboard", border=True):
    with st.container(key="attendance-dashboard-box", border=True):
        st.markdown(
            '<div class="attendance">Attendance Dashboard</div>',
            unsafe_allow_html=True,
        )
    with st.container(key="session"):
        st.markdown(
            '<div class="session-details">Session Selections</div>',
            unsafe_allow_html=True,
        )
    col1, col2 = st.columns(2)
    with col1:
        with st.container(key="stream", border=True):
            st.selectbox("Stream", [])
    with col2:
        with st.container(key="semester", border=True):
            st.selectbox(
                "Select Semester",
                [
                    "I Semester",
                    "II Semester",
                    "III Semester",
                    "IV Semester",
                    "V Semester",
                    "VI Semester",
                    "VII Semester",
                    "VIII Semester",
                ],
            )

with st.container(key="attendance-detail-box", border=True):
    st.markdown(
        """
    <div class="semester" style="text-align:center">Attendance Details</div>
    <br>
    <div class="semester" style="text-align:center"><u>V Semester Attendance</u></div>
    """,
        unsafe_allow_html=True,
    )
    data = pd.DataFrame(
        {
            "ID": [
                "R123", "R124", "R125", "R126", "R127"],
            "Name": [
                "Sujal Gautam",
                "Sanaya Tamang",
                "Nisha Rana",
                "Kusma Chaulagain",
                "Kritika Bhujel",
            ],
            "Present/Absent": ["☑️", "☑️", "☑️", "☑️", "❌"],
        }
    )
    st.table(data)

with st.container(key="attendance-status", border=True):
    data = pd.DataFrame(
        {
            "Total Students": [500],
            "Total Present": [450],
            "Total Absent": [50],
        }
    )
    st.table(data)