import streamlit as st
from narwhals import col

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }
    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0 0 20px;
        min-height:220px !important;
        min-width:275px !important;
    }
    .sidebar-divider {
        width: 85%;
        height: 1px;
        background-color: rgba(255,255,255,0.2);
        margin: 60px auto 0 auto;
    }
    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
    }
    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        font-weight:bold;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:20px;
    }
    
    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        border-radius:10px;
        display:flex;
        align-items:center;
        cursor:pointer;
        font-size:20px;
        justify-content:center;
    }
    .home-icon:hover{
        transform:scale(1.1);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }
    

    </style>
    """,
    unsafe_allow_html=True,
)
left,right=st.columns([1,2],gap="small")

with st.sidebar:
    st.markdown(
                '<div class="sidebar-title">🎓SPAAMS</div>',
                unsafe_allow_html=True
                )
    st.markdown(
                '<div class="sidebar-subtitle">Student Performance Analysis and'
                ' Attendance Monitoring System</div>',
                unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )
    st.markdown(
                '<br><br>',
                unsafe_allow_html=True,
    )
    tasks=st.sidebar.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting"]

    )

    st.markdown(
                '<div class="home-icon">🏠</div>',
                 unsafe_allow_html=True,
    )


