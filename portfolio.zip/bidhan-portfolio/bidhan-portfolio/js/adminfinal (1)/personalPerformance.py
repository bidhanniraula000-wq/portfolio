import pandas as pd
import streamlit as st

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }
    div[data-testid="stMainBlockContainer"]{
        padding-left: 20px !important;
        padding-right: 20px !important;
    }

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px  25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }
    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }
    .student-name{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:#F38C07 !important;
        text-align:center;
    }

    .st-key-performance-box{
        background-color: #E87B12 !important;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:40px;      
    } 
    .performance{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    } 
    .nameDetails{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    }
    .st-key-Details{
        background-color:white !important;;
        border-radius:15px;
        padding:10px;
        min-width:900px;
        min-height:200px; 
    }
    .st-key-details label{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;         
    }
    .st-key-table-box{
        background-color:white;
        border-radius:15px;
        padding:10px;
        min-width:900px;
        min-height:300px;         
    }   
    .personal-details-box{
        font-family:Arial;
        font-size:20px;
        color:black;
        font-weight:bold;
    }
    .personal-details{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black; 
        text-align:center;  
    }
    .detail{
        font-family:Arial;
        font-size:12px;
        color:black;
        text-align:center;
        font-weight:bold;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">🎓SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-subtitle">'
        "Students Performance Analytic and attendance<br>Monitoring System"
        "</div>",
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        """
        <br><br><br><br><br><br>
        <div class="student-name">Student Name</div>""",
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )

with st.container(key="performance-box"):
    st.markdown(
            '<div class="performance">Performance</div>',
            unsafe_allow_html=True,
    )
st.markdown(
    '<div class="nameDetails">Simran Gautam Details</div>',
        unsafe_allow_html=True,
    )
with st.container(key="Details"):
    select_option = st.selectbox(
            key="details",
            label="Details",
            options=["Personal Details", "Academic Details"],
    )
with st.container(key="table-box"):
    st.markdown(
        '<div class="personal-details-box">Simran Gautam Details</div>',
            unsafe_allow_html=True,
        )
    st.markdown(
        '<div class="personal-details">Personal Details</div>',
            unsafe_allow_html=True,
        )
    data = pd.DataFrame(
            {
                "ID": ["R123", "R124", "R125", "R126", "R127"],
                "Name": [
                    "Sujal Gautam",
                    "Sanaya Tamang",
                    "Nisha Rana",
                    "Kusma Chaulagain",
                    "Kritika Bhujel",
                ],
                "Email": [
                    "SujalGautam123@gmail.com",
                    "SanayaTamang124@gmail.com",
                    "NishaRana125@gmail.com",
                    "KusmaChaulagain126@gmail.com",
                    "KritikaBhujel127@gmail.com",
                ],
                "Contact": [
                    "9861000000",
                    "9861000001",
                    "9861000002",
                    "9861000003",
                    "9861000004",
                ],
                "Address": [
                    "Kathmandu",
                    "Pokhara",
                    "Kathmandu",
                    "Bhaktapur",
                    "Pokhara",
                ],
            }
        )
    st.table(data)