import streamlit as st

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }
    div[data-testid="stMainBlockContainer"]{
    padding-left: 20px !important;
    padding-right: 20px !important;
}

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px  25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] > div[role="radiogroup"]{
        gap:6px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label{
        display:flex !important;
        flex-direction:row-reverse;
        align-items:center;
        justify-content:space-between;
        width:275px;
        padding:10px;
        cursor:pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p{
        color:#c9d3dc !important;
        font-size:16px;
        font-family: Arial;
    }

    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }
    .st-key-studentDashboard-box{
        background-color:white;
        padding:10px;
        border-radius:10px;
        margin-bottom:18px;
        margin-left:0px;
        margin-right:0px;
        min-width: 700px; 
        min-height: 50px; 
        align-items:left;
    }
    .studentDashboard{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black;
    }
    .st-key-search-context{
        background-color:white;
        padding:30px;
        border-radius:10px;
        margin-bottom:18px;
        margin-left:0px;
        margin-right:0px;
        min-width: 700px; 
        min-height: 80px; 
        align-items:left; 
    }
    .st-key-search-box{
        background-color:lightgrey;
        padding:16px;
        border-radius:7px;
        min-width:20px;
        width:100% !important;
        min-height:20px;
        align-items:left;   
    }
    .st-key-top-student{
        background-color:#D76F14;
        padding:20px;
        border-radius:7px;
        min-width:20px;
        width:100% !important;
        min-height:20px;
        align-items:left;   
    }
    .top{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
    }
    .st-key-students-data{
        background-color:white !important;
        padding:10px;
        min-width:700px !important;
        min-height:400px;
        border-radius:10px;
    }
    .personal-Details{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black;
        text-align:center;
    }
     .academic-Details{      
         font-family:Arial;  
         font-size:16px;     
         font-weight:bold;   
         color:black;        
         text-align:center;  
     }                       
    
    .personal-details{
        font-family:Arial;
        font-size:12px;
        font-weight:bold;
        color:black;
        text-align:center;
    }
    .academic-details{
        font-family:Arial;
        font-size:12px;
        color:black;
        text-align:center;
        font-weight:bold;
    }
    
    
    </style>
    """,
    unsafe_allow_html=True,
)
sidebar,main = st.columns([1, 2], gap="small")
with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown('<div class="sidebar-subtitle">'
        'Students Performance Analytic and attendance<br>Monitoring System'
        '</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting"
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )
with main:
    with st.container(key="studentDashboard-box"):
        st.markdown('<div class="studentDashboard">Student Dashboard</div>',
                    unsafe_allow_html=True)
    with st.container(key="search-context"):
        col1,col2,col3 = st.columns(3)
        with col1:
            st.markdown('<div class="Search-context"; style="color:black;">Search Context:</div>',
                        unsafe_allow_html=True)
        with col2:
            with st.container(key="search-box"):
                st.markdown('<div class="search">Enter ID or Name</div>',
                            unsafe_allow_html=True)
        with col3:
            with st.container(key="top-student"):
                st.markdown('<div class="top"; style="color:black">Top 10 students</div>',
                            unsafe_allow_html=True)

    with st.container(key="students-data"):
        col4,col5, = st.columns(2)
        with col4:
            st.markdown('<div class="personal-Details"; style="color:black;">Personal Details</div>',
                        unsafe_allow_html=True)
            col6,col7,col8,col9,col10 =st.columns(5)
            with col6:
                st.markdown('<div class="personal-details">ID</div>',
                            unsafe_allow_html=True)
            with col7:
                st.markdown('<div class="personal-details">Full Name</div>',
                            unsafe_allow_html=True)
            with col8:
                st.markdown('<div class="personal-details">Address</div>',
                            unsafe_allow_html=True)
            with col9:
                st.markdown('<div class="personal-details">Contact No.</div>',
                            unsafe_allow_html=True)
            with col10:
                st.markdown('<div class="personal-details">Email</div>',
                            unsafe_allow_html=True)
        with col5 :
            st.markdown('<div class="academic-Details">Academic Details</div>',
                        unsafe_allow_html=True)
            col11,col12,col13,col14 = st.columns(4)
            with col11:
                st.markdown('<div class="academic-details">Stream</div>',
                            unsafe_allow_html=True)
            with col12:
                st.markdown('<div class="academic-details">Semester</div>',
                            unsafe_allow_html=True)
            with col13:
                st.markdown('<div class="academic-details">GPA/Marks</div>',
                            unsafe_allow_html=True)
            with col14:
                st.markdown('<div class="academic-details">Rank</div>',
                            unsafe_allow_html=True)
                