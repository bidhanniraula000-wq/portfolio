import streamlit as st

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }
    div[data-testid="stMainBlockContainer"]{
        padding-left: 5px !important;
        padding-right: 5px !important;
    }

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px 25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] > div[role="radiogroup"]{
        gap:6px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label{
        flex-direction:row-reverse;
        align-items:center;
        justify-content:space-between;
        width:275px;
        padding:10px;
        cursor:pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p{
        color:#c9d3dc !important;
        font-size:16px;
        font-family: Arial;
    }

    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }

    .st-key-setting{
        display: flex;
        background-color: #E87B12 !important;
        border-radius:5px;
        padding:10px;
        align-items:center;
        margin-bottom: 25px;
        min-width:900px;
        min-height:40px;
    }
    .setting-header{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color: black;
    }
    .st-key-data-management-box{
        background-color: white;
        border-radius:14px;
        min-width:900px;
        min-height:200px;
        margin-bottom: 25px;
    }

    .data-management{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black !important;
        text-align:center;
    }
    .st-key-manual-Records{
        background-color:white;
        color:black;
        border-radius:16px;
        padding:20px; 
        min-width:900px;
        min-height:200px;
        margin-bottom: 18px;
    }
    .records-heading{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black !important;
        text-align:center;        
    }

    .st-key-search-box{
        background: #E87B12 !important;
        min-height:210px;
        min-width:45px;
        border-radius:10px;        
    }
    .st-key-upgrade-box{
        background: #E87B12 !important;
        min-height:210px;
        min-width:45px;
        border-radius:10px;        
    }
    .upgrade{
        font-family:Arial;
        font-size:16px;
        color:black !important;
        text-align:center;
    }

    .st-key-upgrade-box label p {
        font-size: 14px !important;
        margin-top:15px;
        margin-bottom:5px;
        margin-left:5px;
        color: black !important;
    }

    .st-key-enable-box{
        background: white !important;
    }

    .st-key-disable-box{
        background: white !important;
    }

    .st-key-conform-enable-box {
        background: white !important;
    }

    .st-key-conform-disable-box {
        background: white !important;
    }

.st-key-upgrade-box div[data-testid="stSelectbox"] {
    width: 90% !important;
    margin: 0 auto !important;
}
.st-key-upgrade-box div[data-baseweb="select"] div {
    color: black !important;
}
    </style>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-subtitle">'
        'Students Performance Analytic and attendance<br>Monitoring System'
        '</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting"
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )

with st.container(key="setting"):
    st.markdown('<div class="setting-header">Setting</div>', unsafe_allow_html=True)

with st.container(key="data-management-box"):
    st.markdown('<div class="data-management">Data Management</div>', unsafe_allow_html=True)

with st.container(key="manual-Records"):
    st.markdown(
        '<div class="records-heading"> Manual Records Control</div><br>',
        unsafe_allow_html=True
    )

    enableDisable_col, upgrade_col = st.columns(2)

    with enableDisable_col:
        with st.container(key="search-box", border=True):
            with st.container(key="search"):
                search = st.text_input("Search: ", placeholder="Search by ID or name")

                enable, disable = st.columns(2)
                with enable:
                    with st.container(key="enable-box", border=True):
                        st.markdown(
                            '<div class="enable">Enable</div>',
                            unsafe_allow_html=True,
                        )
                with disable:
                    with st.container(key="disable-box", border=True):
                        st.markdown(
                            '<div class="disable">Disable</div>',
                            unsafe_allow_html=True,
                        )

                conform_enable, conform_disable = st.columns(2)
                with conform_enable:
                    with st.container(key="conform-enable-box", border=True):
                        st.markdown(
                            '<div class="conform-enable">Conform to enable</div>',
                            unsafe_allow_html=True,
                        )

                with conform_disable:
                    with st.container(key="conform-disable-box", border=True):
                        st.markdown(
                            '<div class="conform-disable">Conform to disable</div>',
                            unsafe_allow_html=True,
                        )

    with upgrade_col:
        with st.container(key="upgrade-box"):
            st.selectbox(
                "Select Semester to upgrade",
                [
                    "I Semester",
                    "II Semester",
                    "III Semester",
                    "IV Semester",
                    "V Semester",
                    "VI Semester",
                    "VII Semester",
                    "VIII Semester",
                ],
                key="semester-select",
            )