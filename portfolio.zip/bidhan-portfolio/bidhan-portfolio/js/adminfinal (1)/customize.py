import streamlit as st

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }
    div[data-testid="stMainBlockContainer"]{
        padding-left: 5px !important;
        padding-right: 5px !important;
    }

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px 25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] > div[role="radiogroup"]{
        gap:6px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label{
        flex-direction:row-reverse;
        align-items:center;
        justify-content:space-between;
        width:275px;
        padding:10px;
        cursor:pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p{
        color:#c9d3dc !important;
        font-size:16px;
        font-family: Arial;
    }

    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }
    .st-key-customize-admin-box{
        background-color: #F38C07;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:40px;
    }
    .customize-admin{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    }
    .st-key-data-management-box{
        background-color: white;
        border-radius:10px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:200px;
    }
     .system-config{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    }
    .st-key-validation-box{
        background-color: #F38C07 ;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:700px;
        min-height:40px;
    }
    .validation{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black;
    }
    .st-key-upload-box{
        border-color: black;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:200px;
        width:20%;
        min-height:50px;
        font-family:Arial;
        font-size:12px;
        font-weight: normal;
        color:black;
    }
    .st-key-upload-main-box{
        border-color: black;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:600px;
        width:50%;
        min-height:50px;
    }
    
    .st-key-import-box >button{
        background-color: #F38C07;
        border-radius:5px;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:600px;
        width:50%;
        min-height:50px;
    }
    .st-key-import-box > button {
        background-color: #001F35 !important;
        color: white !important;
        font-family: Arial !important;
        font-size: 13px !important;
        font-weight: bold !important;
        border-radius: 6px !important;
        border: none !important;
        padding: 8px 16px !important;
        width: 100% !important;
    }
    
    .st-key-manual-record-box{
        background-color: white;
        border-radius:5px;
        border-radius:15px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:300px;
    }  
    .manual-record-header {
        font-family: Arial;
        font-size: 16px;
        font-weight: bold;
        color: black;
        text-align: center;
        margin-bottom: 10px;
    }

    .st-key-add-user-box, .st-key-delete-user-box, .st-key-update-user-box {
        background-color: #F38C07;
        border-radius: 10px;
        padding: 15px;
        min-height: 250px;
    }

    .card-title {
        font-family: Arial;
        font-size: 16px;
        font-weight: bold;
        color: black;
        text-align: center;
        margin-bottom: 15px;
    }
    .st-key-input-box{
        background-color: white;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:100px;
        min-height:30px;
        
    }
        
    </style>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        """<div class="sidebar-subtitle">
        'Students Performance Analytic and attendance<br>Monitoring System'
        </div>""",
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting"
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )
with st.container(key="customize-admin-box"):
    st.markdown(
        '<div class="customize-admin">Customize Admin</div>',
        unsafe_allow_html=True,
    )
st.markdown(
    '<div class="system-config">System Configuration & Data Management</div>',
    unsafe_allow_html=True,
)
with st.container(key="data-management-box"):
    with st.container(key="validation-box", horizontal=True):
        st.markdown(
            '<div class="validation">Upload CSV & Smart Validation Engine</div>',
            unsafe_allow_html=True,
        )
    with st.container(key="upload-main-box", horizontal=True):
        with st.container(key="upload-box", border=True):
            st.markdown(
                """
                    <div class="validation">
                        Upload CSV
                        <br>
                        Add Students
                        <br>
                        Delete Students
                        <br>
                        Update Students
                    </div>""",
                unsafe_allow_html=True,

        )
        st.markdown(
            '<div class="file">📁 file_uploader.CSV</div>',
            unsafe_allow_html=True,
        )
        st.button("Validation and Import", key="import-box")

with st.container(key="manual-record-box"):
    st.markdown('<div class="manual-record-header">Manual Records Control</div>', unsafe_allow_html=True)

    add_col, delete_col, update_col = st.columns(3)

    with add_col:
        with st.container(key="add-user-box"):
            st.markdown('<div class="card-title">ADD USER</div>',
                        unsafe_allow_html=True)
            st.text_input("input field", placeholder="input field")

    with delete_col:
        with st.container(key="delete-user-box"):
            st.markdown('<div class="card-title">DELETE USER</div>',
                     unsafe_allow_html=True)
            st.text_input("Enter ID", placeholder="Enter ID")
            st.text_input("Confirm ID", placeholder="Confirm ID")

    with update_col:
        with st.container(key="update-user-box"):
            st.markdown('<div class="card-title">Update</div>',
                     unsafe_allow_html=True)
            st.text_input("Search", placeholder="Search........",
                        label_visibility="collapsed")