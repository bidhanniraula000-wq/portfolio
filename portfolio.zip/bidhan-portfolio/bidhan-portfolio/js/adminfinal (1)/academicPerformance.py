import pandas as pd
import streamlit as st
from altair import Stream
from streamlit import container

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }
    div[data-testid="stMainBlockContainer"]{
        padding-left: 5px !important;
        padding-right: 5px !important;
         padding-top: 5rem !important;
    }

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px  25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }
    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }
    .student-name{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:#F38C07 !important;
        text-align:center;
        }

    .st-key-performance-box{
        background-color: #F38C07;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:40px;
    }
    .performance{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    }
    .nameDetails{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    }
    .st-key-Details{
        background-color:white;
        border-radius:15px;
        padding:10px;
        min-width:900px;
        min-height:300px;
    }
    .st-key-details label{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
    }
    .st-key-table-box{
        background-color:white;
        border-radius:15px;
        padding:10px;
        min-width:900px;
        min-height:500px;
    }
    .academic-details-box{
        font-family:Arial;
        font-size:20px;
        color:black;
        font-weight:bold;
    }
     .academic-details{
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        color:black;
        text-align:center;
        text-decoration:underline;
    }
    .detail{
        font-family:Arial;
        font-size:12px;
        color:black;
        text-align:center;
        font-weight:bold;
    }
     .st-key-submit{
        background-color:#F38C07;
        border-radius:10px;
        padding:10px;
        min-width:900px;
        min-height:40px;
    }
    .logout{
        font-family:Arial;
        font-size:20px;
        font-weight:bold;
        color:black;
         display: flex;
        align-items: center;
        justify-content: center;
    }
      </style>
    """,
    unsafe_allow_html=True,
)
# sidebar, main = st.columns([1, 2], gap="small")
with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">🎓SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown('<div class="sidebar-subtitle">'
                'Students Performance Analytic and attendance<br>Monitoring System'
                '</div>',
                unsafe_allow_html=True,
                )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )
    st.markdown("""

        <br><br><br><br><br><br>
        <div class="student-name">Student Name</div>""",
                unsafe_allow_html=True,
                )
    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )
# with main:
with st.container(key="performance-box"):
        st.markdown('<div class="performance">Performance</div>',
                    unsafe_allow_html=True, )
st.markdown('<div class="nameDetails">Simran Gautam Details</div>',
                unsafe_allow_html=True, )
with st.container(key="Details"):
        select_option = st.selectbox(
            key="details",
            label="Details",
            options=["Academic Details","Personal Details"]
        )
with st.container(key="table-box"):
        st.markdown('<div class="academic-details-box">Simran Gautam Details</div>',
                    unsafe_allow_html=True)
        st.markdown('<div class="academic-details">Academic Details</div>',
                    unsafe_allow_html=True, )

        st.markdown("""
            <br>""",
            unsafe_allow_html=True,
           )
        data=pd.DataFrame(
            {
                "Register ID" : ['R123','R124','R125'],
                "Stream" : ["BCA", "BCA", "BCA"],
                "Semester" : ["I", "IV", "VII"],
                "Attendance" : [1, 2, 1],
                "Assignments": [1, 2, 1],
                "Lab": [1, 2, 1],
                "Overall Activities": [1, 2, 1],
                "Total Average": [1, 2, 1],
                "Board Marks": [1, 2, 1],
            }
        )
        st.table(data)

        col1, col2 =st.columns(2)
        with col1:
            st.markdown('<div class="detail"><u>Attendance Chart</u></div>',
                            unsafe_allow_html=True, )
        with col2:
            st.markdown('<div class="detail"><u>All Details Chart</u></div>',
                            unsafe_allow_html=True,)
with st.container(key="submit"):
                st.markdown('<div class="logout"><u>Log-out</u></div>',
                            unsafe_allow_html=True, )



