import streamlit as st

st.title("🎓SPAAMS")
st.subheader("Students Performance Analytics and Attendance Monitoring System")
role=st.radio(
        "Select Role",
        ["Admin", "Teacher", "Student"],
        horizontal=True
    )
Username=st.text_input("Username: ",placeholder="Admin Username")
Password=st.text_input("Password: ", placeholder="Enter Password",type="password")


if st.button("Login"):
    if Username==" " or Password=="":
         st.warning("Please enter Username and Password")
else:
         if role == "Teacher" or role == "Student":
             st.error("Invalid User")
         else:
              st.success("Login Successful")

st.button("🏚️")
