import streamlit as st
from streamlit import container

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }
        div[data-testid="stMainBlockContainer"] {
        padding-left: 200px !important;
        padding-right: 200px !important;
        padding-top: 5rem !important;
    }

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px  25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label{
        display:flex !important;
        flex-direction:row-reverse;
        align-items:center;
        justify-content:space-between;
        width:275px;
        padding:10px;
        cursor:pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p{
        color:#c9d3dc !important;
        font-size:16px;
        font-family: Arial;
    }

    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }

    .st-key-semester-wise-dashboard{
        background-color: white !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        min-width: 900px;
        width: 100%; 
        min-height: 300px;   
    }
    .attendance{
        font-family: Arial;
        color:black;
        font-weight:bold;
        font-size:16px !important;
        margin-left:0px; !important;
    }
    .stMainBlockContainer {
        max-width: 100% !important; /* Remove default max-width constraint */
        padding-left: 0px !important;
        padding-right:auto !important;
    }
    .st-key-box {
        background-color: white !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        min-width: 900px;
        width: 100%; 
        min-height: 300px;  
        margin-left:0px; !important;
    }
    .st-key-semester-wise-box{
        background-color: #E87B12 !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        min-width: 700px;
        min-height: 40px;           
    }

    .st-key-session{
        background-color: #E87B12 !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        min-width: 800px;
        min-height: 40px;     
    }
    .session-details{
        font-family: Arial;
        color:black;
        font-weight:bold;
        font-size:16px !important;
    }
     .st-key-logout-section {
        background-color: white !important;
        border-radius: 10px;
        min-width: 900px;
        width: 100%; 
        min-height: 250px; 
    }
   div[data-testid="stSelectbox"] label {
   font-family: Arial;
   font-weight:bold;
   font-size:16px !important;
    color: black;
}
    
 </style>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">🎓SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-subtitle">'
        'Students Performance Analytic and attendance<br>Monitoring System'
        '</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting",
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )

with st.container(key="semester-wise-dashboard", border=True):
    with st.container(key="semester-wise-box", border=True):
        st.markdown('<div class="attendance">Semester-wise Dashboard</div>',
                        unsafe_allow_html=True)
    with st.container(key="session"):
            st.markdown(
                '<div class="session-details">Session Selections</div>',
                unsafe_allow_html=True,
            )
    col1, col2 = st.columns(2)
    with col1:
        with st.container(key="stream", border=True):
            st.selectbox(
                    "Select Stream",
                    []
             )
    with col2:
        with st.container(key="semester", border=True):
            st.selectbox(
                    "Select Semester",
                    [
                        "I Semester",
                        "II Semester",
                        "III Semester",
                        "IV Semester",
                        "V Semester",
                        "VI Semester",
                        "VII Semester",
                        "VIII Semester",
                    ]
                )
with st.container(key="box", border=True):
    st.markdown('<div class="semester" style="text-align:center"></div>',
                    unsafe_allow_html=True,)
with st.container(key="logout-section", border=True):
    st.markdown('<div class="semester"></div>',
                    unsafe_allow_html=True)




