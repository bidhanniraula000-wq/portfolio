import streamlit as st

st.markdown(
    """
    <style>
    .stApp{
        background-color:lightgray;
    }

    section[data-testid="stSidebar"]{
        background-color:#001F35;
        border-radius:20px 0px 0px 20px;
        min-height:300px !important;
        min-width:300px !important;
    }

    .sidebar-divider{
        width:85%;
        height:1px;
        background-color:rgba(255,255,255,0.2);
        margin:15px  25px;
    }

    .sidebar-title{
        font-family:Arial;
        font-size:32px;
        font-weight:bold;
        color:white;
        text-align:center;
        letter-spacing:2px;
        margin-top:10px;
    }

    .sidebar-subtitle{
        font-family:Arial;
        font-size:11px;
        color:white;
        text-align:center;
        margin-top:3px;
        margin-bottom:0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label{
        display:flex !important;
        flex-direction:row-reverse;
        align-items:center;
        justify-content:space-between;
        width:275px;
        padding:10px;
        cursor:pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p{
        color:#c9d3dc !important;
        font-size:16px;
        font-family: Arial;
    }

    .home-icon{
        position:fixed;
        bottom:25px;
        left:30px;
        width:42px;
        height:42px;
        border-radius:5px;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
        font-size:20px;
        box-shadow:0px 2px 6px rgba(0,0,0,0.4);
    }

    .home-icon:hover{
        transform:scale(1.08);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);
    }

    .st-key-setting{
        background-color: white !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        width: 700px; 
        min-height: 30px;   
    }
    .setting{
        font-family: Arial;
        color:black;
        font-weight:bold;
        font-size:24px !important;
        text-align:center;
        margin-left:0px; !important;
    }
    .stMainBlockContainer {
        max-width: 100% !important; /* Remove default max-width constraint */
        padding-left: 0px !important;
        padding-right:auto !important;
    }
    .st-key-upgrade-sem {
        background-color: white !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        width: 700px !important;    
        min-height: 500px;
        margin-left:0px; !important;
    }
    .semester{
    font-family: Arial;
        color:black;
        font-weight:bold;
        font-size:24px !important;
        margin-left:0px; !important;
    }
    .st-key-logout-section {
        background-color: white !important;
        border: none !important;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 18px;
        width: 700px; 
        min-height: 30px;
        margin-left:0px; !important;
    }

    .st-key-logout-section div[data-testid="stVerticalBlock"] {
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important; /* Centers horizontally */
        justify-content: center !important;
        width: 100%;
    }
    .st-key-logout-button {
        display: flex;
        justify-content: center; /* Centers horizontally */
        align-items: center;     /* Centers vertically */
        min-width:100%px;
    }
    .st-key-logout-button button {
        background-color: #EA6A16 !important; 
        color: white !important;
        font-weight: bold;
        padding: 10px 30px;
        border-radius: 5px;
        width: auto; 
    }
    .st-key-logout-button button:hover {
        transform:scale(1);
        box-shadow:0px 0px 10px rgba(0,0,0,0.5);     
    }
 </style>
    """,
    unsafe_allow_html=True,
)

left, right = st.columns([1, 2], gap="small")

with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">🎓SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-subtitle">'
        'Students Performance Analytic and attendance<br>Monitoring System'
        '</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting",
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )

with right:
    with st.container(key="setting", border=True):
        st.markdown('<div class="setting">Setting</div>',
                    unsafe_allow_html=True)

    with st.container(key="upgrade-sem", border=True):
        st.markdown(
            """
        <div class="semester" style="text-align:center">Upgrade Semester VI to VII</div>
        <br>
        <div class="semester" style="text-align:center"><u>VII semester details</u></div>
        """,
            unsafe_allow_html=True)

    with st.container(key="logout-section", border=True):
        st.markdown('<div class="semester"></div>',
                    unsafe_allow_html=True)
        st.button("Logout", key="logout-button")
