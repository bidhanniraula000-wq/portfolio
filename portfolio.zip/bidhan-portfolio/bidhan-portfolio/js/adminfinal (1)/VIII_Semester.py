import pandas as pd
import streamlit as st

# # Set wide layout so boxes fit nicely
# st.set_page_config(layout="wide")

st.markdown(
    """
    <style>
    .stApp {
        background-color: lightgray;
    }

    section[data-testid="stSidebar"] {
        background-color: #001F35;
        border-radius: 0px 20px 20px 0px;
    }

    div[data-testid="stMainBlockContainer"] {
        padding-left: 5px !important;
        padding-right: 5px !important;
        padding-top: 5rem !important;
    }

    .sidebar-divider {
        width: 85%;
        height: 1px;
        background-color: rgba(255,255,255,0.2);
        margin: 15px auto;
    }

    .sidebar-title {
        font-family: Arial;
        font-size: 32px;
        font-weight: bold;
        color: white;
        text-align: center;
        letter-spacing: 2px;
        margin-top: 10px;
    }

    .sidebar-subtitle {
        font-family: Arial;
        font-size: 11px;
        color: white;
        text-align: center;
        margin-top: 3px;
        margin-bottom: 0px;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label {
        display: flex !important;
        flex-direction: row-reverse;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        padding: 10px;
        cursor: pointer;
    }

    section[data-testid="stSidebar"] div[data-testid="stRadio"] label p {
        color: white !important;
        font-size: 16px;
        font-family: Arial;
    }

    .home-icon {
        position: fixed;
        bottom: 25px;
        left: 30px;
        width: 42px;
        height: 42px;
        border-radius: 5px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 20px;
        box-shadow: 0px 2px 6px rgba(0,0,0,0.4);
        background-color: #001F35;
    }

    .home-icon:hover {
        transform: scale(1.08);
        box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
    }
    .st-key-setting-box {
        display: flex;
        background-color: #E87B12 !important;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:40px;
    }
    .setting{
        font-family: Arial;
        font-size: 20px;
        font-weight:bold;
        color:black;
    }
    .st-key-upgrade-semester-box{
        display: flex;
        background-color: #E87B12 !important;
        border-radius:5px;
        padding:10px;
        align-items:center;
        min-width:900px;
        min-height:40px;
    }
    .upgrade{
        font-family: Arial;
        font-size: 20px;
        font-weight:bold;
        color:black;
    }

    .st-key-details-box{
        background-color:white;
        border-radius:15px;
        padding:10px;
        min-width:900px;
        min-height:300px; 
    }

    .details{
       font-family: Arial;
        font-size: 16px;
        font-weight:bold;
        color:black;
        text-align: center;
        text-decoration: underline; 
    } 

    .st-key-logout-box{
        display: flex;
        align-items: center;
        background-color: #E87B12 !important;
        min-width:900px;
        min-height:40px;
    }
    .logout{
        font-family: Arial;
        font-size: 20px;
        font-weight:bold;
        color:black;
        text-align: center;
    }
    .data{
        font-family: Arial;
        font-size: 20px;
        font-weight:bold;
        color:black;
        text-align: center;        
    }

    </style>
    """,
    unsafe_allow_html=True,
)
with st.sidebar:
    st.markdown(
        '<div class="sidebar-title">🎓SPAAMS</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-subtitle">'
        "Students Performance Analytic and attendance<br>Monitoring System"
        "</div>",
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="sidebar-divider"></div>',
        unsafe_allow_html=True,
    )

    tasks = st.radio(
        "",
        [
            "Student Dashboard",
            "Semester-Wise Details",
            "Semester-Wise Dashboard",
            "Attendance Monitoring",
            "Customize Admin",
            "Setting",
        ],
    )

    st.markdown(
        '<div class="home-icon">🏠</div>',
        unsafe_allow_html=True,
    )
with st.container(key="setting-box", border=True):
    st.markdown(
        '<div class="setting">Setting</div>',
        unsafe_allow_html=True,
    )
st.markdown(
    '<div class="upgrade">Upgrade Semester</div>',
    unsafe_allow_html=True,
)
with st.container(key="upgrade-semester-box", border=True):
    st.markdown(
        '<div class="upgrade">Upgrade Semester VII to Semester VIII</div>',
        unsafe_allow_html=True,
    )

with st.container(key="details-box", border=True):
    st.markdown(
        '<div class="details">VIII Semester Details</div>',
        unsafe_allow_html=True,
    )
    data = pd.DataFrame(
        {
            "ID": [
                "R123", "R124", "R125", "R126", "R127"],
            "Name": [
                "Sujal Gautam",
                "Sanaya Tamang",
                "Nisha Rana",
                "Kusma Chaulagain",
                "Kritika Bhujel",
            ],
            "Email": [
                "SujalGautam123@gmail.com",
                "SanayaTamang124@gmail.com",
                "NishaRana125@gmail.com",
                "KusmaChaulagain126@gmail.com",
                "KritikaBhujel127@gmail.com",
            ],
            "Contact": [
                "9861000000",
                "9861000001",
                "9861000002",
                "9861000003",
                "9861000004",
            ],
            "Address": [
                "Kathmandu",
                "Pokhara",
                "Kathmandu",
                "Bhaktapur",
                "Pokhara"
            ],
            "Stream": [
                "BCA",
                "BCA",
                "BCA",
                "BCA",
                "BCA"
            ],
            "Upgraded to ": [
                "II Semester",
                "II Semester",
                "II Semester",
                "II Semester",
                "II Semester"
            ],
            "Batch": [
                "2024",
                "2024",
                "2024",
                "2024",
                "2024"
            ]
        }
    )
    st.table(data)
with st.container(key="logout-box", border=True):
    st.markdown(
        '<div class="logout">Logout</div>',
        unsafe_allow_html=True,
    )

